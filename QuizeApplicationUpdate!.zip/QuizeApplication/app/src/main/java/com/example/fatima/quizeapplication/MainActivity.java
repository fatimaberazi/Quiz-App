package com.example.fatima.quizeapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private int score;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void checkAnswers(View view) {
        EditText firstQuestion = (EditText) findViewById(R.id.first_question_edit_text);
        if (firstQuestion.getText().toString().replaceAll("\\s+","").toString().equalsIgnoreCase("EvanSpiegel")) {
            score = score + 1;
        }
        RadioGroup secondQuestion = (RadioGroup) findViewById(R.id.cd_question_2_radio_group);
        if (secondQuestion.getCheckedRadioButtonId() == R.id.cd_question_2_a) {
            score = score + 1;
        } else {
            Log.i("Message", "This is for you udacity reviewer!");
        }
        CheckBox questionThreeA = (CheckBox) findViewById(R.id.cd_question_3_a);
        CheckBox questionThreeB = (CheckBox) findViewById(R.id.cd_question_3_b);
        CheckBox questionThreeC = (CheckBox) findViewById(R.id.cd_question_3_c);
        CheckBox questionThreeD = (CheckBox) findViewById(R.id.cd_question_3_d);
        if (questionThreeA.isChecked() == false && questionThreeB.isChecked() == true && questionThreeC.isChecked() == false && questionThreeD.isChecked() == true) {
            score = score + 1;
        }
        EditText fourthQuestion = (EditText) findViewById(R.id.fourth_question_edit_text);
        if (fourthQuestion.getText().toString().replaceAll("\\s+","").equalsIgnoreCase("Graphite")) {
            score = score + 1;
        }
        Toast.makeText(getApplicationContext(), "You answered " + score, Toast.LENGTH_LONG).show();
        score = 0;
    }

}